import React from 'react';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface StatsPanelProps {
  completedOrders: number;
  avgTime: number;
}

export const StatsPanel: React.FC<StatsPanelProps> = ({ completedOrders, avgTime }) => {
  const data = [
    { name: 'Mon', orders: 12 },
    { name: 'Tue', orders: 19 },
    { name: 'Wed', orders: 15 },
    { name: 'Thu', orders: 22 },
    { name: 'Today', orders: completedOrders }, // Dynamic
  ];

  return (
    <div className="bg-white dark:bg-slate-900 p-4 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800 transition-colors duration-300">
      <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-4">Performance Pulse</h3>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-indigo-50 dark:bg-indigo-950/30 p-3 rounded-md">
          <p className="text-xs text-indigo-500 dark:text-indigo-400 font-semibold uppercase">Orders Today</p>
          <p className="text-2xl font-bold text-indigo-900 dark:text-indigo-200">{completedOrders}</p>
        </div>
        <div className="bg-emerald-50 dark:bg-emerald-950/30 p-3 rounded-md">
          <p className="text-xs text-emerald-500 dark:text-emerald-400 font-semibold uppercase">Avg Prep Time</p>
          <p className="text-2xl font-bold text-emerald-900 dark:text-emerald-200">{avgTime} <span className="text-sm font-normal text-emerald-700 dark:text-emerald-400">min</span></p>
        </div>
      </div>

      <div className="h-48 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} stroke="#94a3b8" />
            <Tooltip 
                cursor={{fill: 'rgba(241, 245, 249, 0.2)'}}
                contentStyle={{ 
                  borderRadius: '8px', 
                  border: 'none', 
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                  backgroundColor: 'var(--tw-prose-invert-bg, #1e293b)',
                  color: '#f8fafc'
                }}
            />
            <Bar dataKey="orders" radius={[4, 4, 0, 0]}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={index === data.length - 1 ? '#4f46e5' : '#cbd5e1'} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};