import React from 'react';
import { Order, OrderStatus } from '../types';
import { Clock, CheckCircle, Truck } from 'lucide-react';

interface OrderCardProps {
  order: Order;
  onUpdateStatus: (id: string, status: OrderStatus) => void;
  onSendSignal: (id: string, message: string) => void;
}

export const OrderCard: React.FC<OrderCardProps> = ({ order, onUpdateStatus, onSendSignal }) => {
  const timeElapsed = Math.floor((Date.now() - new Date(order.createdAt).getTime()) / 60000);
  
  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.PENDING: return 'border-orange-200 dark:border-orange-900 bg-orange-50 dark:bg-orange-950/20';
      case OrderStatus.PREPARING: return 'border-blue-200 dark:border-blue-900 bg-blue-50 dark:bg-blue-950/20';
      case OrderStatus.READY: return 'border-green-200 dark:border-green-900 bg-green-50 dark:bg-green-950/20';
      default: return 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900';
    }
  };

  return (
    <div className={`border-l-4 rounded-lg shadow-sm p-4 mb-4 ${getStatusColor(order.status)} animate-fade-in transition-colors duration-300`}>
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="font-bold text-lg text-slate-800 dark:text-slate-100">#{order.id.split('-')[1]} <span className="text-sm font-normal text-slate-500 dark:text-slate-400">for {order.customerName}</span></h3>
          <div className="flex items-center text-xs text-slate-500 dark:text-slate-400 mt-1">
            <Clock size={12} className="mr-1" />
            <span>{timeElapsed} mins ago</span>
            {order.riderMessage && (
               <span className="ml-2 px-2 py-0.5 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200 rounded-full font-medium">
                 Signal: {order.riderMessage}
               </span>
            )}
          </div>
        </div>
        <div className="text-right">
          <span className="block font-bold text-slate-900 dark:text-slate-100">${order.totalAmount.toFixed(2)}</span>
          <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
            order.status === OrderStatus.PENDING ? 'bg-orange-200 text-orange-800 dark:bg-orange-900 dark:text-orange-100' :
            order.status === OrderStatus.PREPARING ? 'bg-blue-200 text-blue-800 dark:bg-blue-900 dark:text-blue-100' :
            'bg-green-200 text-green-800 dark:bg-green-900 dark:text-green-100'
          }`}>
            {order.status}
          </span>
        </div>
      </div>

      <div className="border-t border-b border-slate-100 dark:border-slate-700/50 py-3 mb-3">
        <ul className="text-sm text-slate-700 dark:text-slate-300 space-y-1">
          {order.items.map((item, idx) => (
            <li key={idx} className="flex justify-between">
              <span>{item.quantity}x {item.name}</span>
              <span className="text-slate-400 dark:text-slate-500">${(item.price * item.quantity).toFixed(2)}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Rider Info Section */}
      {order.rider && order.status !== OrderStatus.COMPLETED && (
        <div className="bg-white/50 dark:bg-slate-800/50 rounded p-2 mb-3 flex items-center justify-between text-sm">
           <div className="flex items-center text-slate-700 dark:text-slate-300">
             <Truck size={16} className="mr-2 text-indigo-600 dark:text-indigo-400" />
             <span className="font-medium">{order.rider.name}</span>
           </div>
           <span className={`text-xs font-bold ${order.rider.status === 'ARRIVED' ? 'text-red-600 dark:text-red-400 animate-pulse' : 'text-slate-500 dark:text-slate-400'}`}>
             {order.rider.status === 'ARRIVED' ? 'ARRIVED' : `${order.rider.arrivalTime} min away`}
           </span>
        </div>
      )}

      {/* Actions */}
      <div className="flex flex-wrap gap-2">
        {order.status === OrderStatus.PENDING && (
          <button 
            onClick={() => onUpdateStatus(order.id, OrderStatus.PREPARING)}
            className="flex-1 bg-indigo-600 text-white py-2 px-4 rounded-md font-semibold hover:bg-indigo-700 dark:hover:bg-indigo-500 active:scale-95 transition-all shadow-sm"
          >
            Accept Order
          </button>
        )}

        {order.status === OrderStatus.PREPARING && (
          <>
            <button 
              onClick={() => onSendSignal(order.id, "Delayed 5m")}
              className="flex-none px-3 py-2 bg-yellow-100 dark:bg-yellow-900/40 text-yellow-800 dark:text-yellow-200 rounded-md font-medium hover:bg-yellow-200 dark:hover:bg-yellow-900/60 transition-colors flex items-center"
              title="Signal +5 Mins"
            >
              <Clock size={16} className="mr-1" /> +5m
            </button>
             <button 
              onClick={() => onSendSignal(order.id, "Delayed 10m")}
              className="flex-none px-3 py-2 bg-yellow-100 dark:bg-yellow-900/40 text-yellow-800 dark:text-yellow-200 rounded-md font-medium hover:bg-yellow-200 dark:hover:bg-yellow-900/60 transition-colors flex items-center"
              title="Signal +10 Mins"
            >
              +10m
            </button>
            <button 
              onClick={() => onUpdateStatus(order.id, OrderStatus.READY)}
              className="flex-1 bg-green-600 text-white py-2 px-4 rounded-md font-semibold hover:bg-green-700 dark:hover:bg-green-500 active:scale-95 transition-all shadow-sm flex justify-center items-center"
            >
              <CheckCircle size={18} className="mr-2" /> Mark Ready
            </button>
          </>
        )}

        {order.status === OrderStatus.READY && (
           <button 
             onClick={() => onUpdateStatus(order.id, OrderStatus.COMPLETED)}
             className="w-full bg-slate-800 dark:bg-slate-700 text-white py-3 px-4 rounded-md font-semibold hover:bg-slate-900 dark:hover:bg-slate-600 active:scale-95 transition-all shadow-sm flex justify-center items-center"
           >
             Handoff to Rider
           </button>
        )}
      </div>
    </div>
  );
};