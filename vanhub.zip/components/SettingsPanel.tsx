import React from 'react';
import { Moon, Sun, Store, CreditCard } from 'lucide-react';

interface SettingsPanelProps {
  storeName: string;
  setStoreName: (name: string) => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ 
  storeName, 
  setStoreName, 
  isDarkMode, 
  toggleTheme 
}) => {
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800 p-6">
        <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center">
          <Store className="mr-2 text-indigo-600 dark:text-indigo-400" size={20} />
          Store Profile
        </h3>
        
        <div className="space-y-4">
          <div>
            <label htmlFor="storeName" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
              Store Display Name
            </label>
            <input
              type="text"
              id="storeName"
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
              className="w-full px-4 py-2 rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-colors"
              placeholder="e.g. Green Grocer"
            />
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              This name will be displayed on your dashboard and invoices.
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800 p-6">
        <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center">
          <Moon className="mr-2 text-indigo-600 dark:text-indigo-400" size={20} />
          Appearance
        </h3>
        
        <div className="flex items-center justify-between">
          <div>
            <span className="block text-sm font-medium text-slate-700 dark:text-slate-300">Dark Mode</span>
            <span className="text-xs text-slate-500 dark:text-slate-400">Reduce eye strain during night shifts.</span>
          </div>
          
          <button
            onClick={toggleTheme}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:focus:ring-offset-slate-900 ${
              isDarkMode ? 'bg-indigo-600' : 'bg-slate-200'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                isDarkMode ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800 p-6 opacity-60 pointer-events-none">
        <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center">
          <CreditCard className="mr-2 text-slate-400" size={20} />
          Billing (Coming Soon)
        </h3>
        <p className="text-sm text-slate-500 dark:text-slate-400">
           Manage your ONDC commission settings and payouts.
        </p>
      </div>
    </div>
  );
};