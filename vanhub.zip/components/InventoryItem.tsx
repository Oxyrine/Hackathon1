import React from 'react';
import { Product, StockStatus } from '../types';
import { AlertTriangle, Check, XOctagon } from 'lucide-react';

interface InventoryItemProps {
  product: Product;
  onUpdateStatus: (id: string, status: StockStatus) => void;
}

export const InventoryItem: React.FC<InventoryItemProps> = ({ product, onUpdateStatus }) => {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-3 mb-3 flex items-center justify-between shadow-sm transition-colors duration-300">
      <div className="flex items-center space-x-3">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-12 h-12 rounded bg-slate-100 dark:bg-slate-800 object-cover"
        />
        <div>
          <h4 className="font-semibold text-slate-800 dark:text-slate-100">{product.name}</h4>
          <p className="text-xs text-slate-500 dark:text-slate-400">{product.category}</p>
        </div>
      </div>
      
      <div className="flex bg-slate-100 dark:bg-slate-800 rounded-lg p-1">
        <button
          onClick={() => onUpdateStatus(product.id, StockStatus.IN_STOCK)}
          className={`p-2 rounded-md transition-all ${
            product.status === StockStatus.IN_STOCK 
              ? 'bg-green-500 text-white shadow-sm' 
              : 'text-slate-400 dark:text-slate-500 hover:text-green-600 dark:hover:text-green-400'
          }`}
          title="In Stock"
        >
          <Check size={18} />
        </button>
        <button
          onClick={() => onUpdateStatus(product.id, StockStatus.LOW_STOCK)}
          className={`p-2 rounded-md transition-all ${
            product.status === StockStatus.LOW_STOCK 
              ? 'bg-yellow-500 text-white shadow-sm' 
              : 'text-slate-400 dark:text-slate-500 hover:text-yellow-600 dark:hover:text-yellow-400'
          }`}
          title="Low Stock"
        >
          <AlertTriangle size={18} />
        </button>
        <button
          onClick={() => onUpdateStatus(product.id, StockStatus.OUT_OF_STOCK)}
          className={`p-2 rounded-md transition-all ${
            product.status === StockStatus.OUT_OF_STOCK 
              ? 'bg-red-500 text-white shadow-sm' 
              : 'text-slate-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400'
          }`}
          title="Out of Stock (Stop Orders)"
        >
          <XOctagon size={18} />
        </button>
      </div>
    </div>
  );
};