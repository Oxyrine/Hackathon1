import { Order, OrderStatus, Product, StockStatus } from '../types';

export const INITIAL_INVENTORY: Product[] = [
  {
    id: 'p1',
    name: 'Organic Whole Milk',
    category: 'Dairy',
    price: 3.50,
    status: StockStatus.IN_STOCK,
    image: 'https://picsum.photos/100/100?random=1'
  },
  {
    id: 'p2',
    name: 'Sourdough Bread',
    category: 'Bakery',
    price: 5.00,
    status: StockStatus.LOW_STOCK,
    image: 'https://picsum.photos/100/100?random=2'
  },
  {
    id: 'p3',
    name: 'Avocados (Pack of 3)',
    category: 'Produce',
    price: 4.50,
    status: StockStatus.IN_STOCK,
    image: 'https://picsum.photos/100/100?random=3'
  },
  {
    id: 'p4',
    name: 'Free Range Eggs (12)',
    category: 'Dairy',
    price: 6.00,
    status: StockStatus.OUT_OF_STOCK,
    image: 'https://picsum.photos/100/100?random=4'
  },
  {
    id: 'p5',
    name: 'Almond Butter',
    category: 'Pantry',
    price: 12.00,
    status: StockStatus.IN_STOCK,
    image: 'https://picsum.photos/100/100?random=5'
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ONDC-1023',
    customerName: 'Aarav Patel',
    totalAmount: 13.50,
    status: OrderStatus.PENDING,
    createdAt: new Date(Date.now() - 1000 * 60 * 2), // 2 mins ago
    items: [
      { productId: 'p1', name: 'Organic Whole Milk', quantity: 1, price: 3.50 },
      { productId: 'p2', name: 'Sourdough Bread', quantity: 2, price: 5.00 }
    ]
  },
  {
    id: 'ONDC-1024',
    customerName: 'Priya Sharma',
    totalAmount: 4.50,
    status: OrderStatus.PREPARING,
    createdAt: new Date(Date.now() - 1000 * 60 * 15), // 15 mins ago
    rider: {
      name: 'Ramesh Kumar',
      phone: '555-0123',
      arrivalTime: 2,
      status: 'ASSIGNED'
    },
    items: [
      { productId: 'p3', name: 'Avocados (Pack of 3)', quantity: 1, price: 4.50 }
    ]
  },
  {
    id: 'ONDC-1021',
    customerName: 'Vikram Singh',
    totalAmount: 12.00,
    status: OrderStatus.READY,
    createdAt: new Date(Date.now() - 1000 * 60 * 25), // 25 mins ago
    rider: {
      name: 'Sunil Das',
      phone: '555-0199',
      arrivalTime: 0,
      status: 'ARRIVED'
    },
    items: [
      { productId: 'p5', name: 'Almond Butter', quantity: 1, price: 12.00 }
    ]
  }
];