import { GoogleGenAI } from "@google/genai";
import { Order, Product, StockStatus } from "../types";

const apiKey = process.env.API_KEY || '';

// Safely initialize the client. We check for key presence before calling methods.
const ai = new GoogleGenAI({ apiKey });

export const getVendorInsights = async (
  orders: Order[],
  inventory: Product[]
): Promise<string> => {
  if (!apiKey) {
    return "API Key is missing. Please configure your environment to use AI insights.";
  }

  const inventorySummary = inventory.map(p => 
    `- ${p.name}: ${p.status}`
  ).join('\n');

  const orderSummary = orders.map(o => 
    `- Order ${o.id} (${o.status}): ${o.items.map(i => i.name).join(', ')}`
  ).join('\n');

  const prompt = `
    You are an intelligent assistant for a Quick Commerce Vendor.
    Analyze the following current inventory and active orders to provide 3 short, actionable bullet points.
    Focus on potential bottlenecks, items selling fast that might need restocking, or orders that are risking delay.
    Keep it very concise (under 50 words total).

    Current Inventory:
    ${inventorySummary}

    Active Orders:
    ${orderSummary}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "No insights available at the moment.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Unable to generate insights right now. Please try again later.";
  }
};